inside elastic folder
i have made all the js files of bootstrap and tableau sdk as local by downloading theri js files as on tableau 10.1
just place this code in wamp and you can see bingo
simulator is not there in this zip.