<?php
error_reporting(E_ALL ^ E_DEPRECATED);
$dbhost = 'localhost';  // MYSQL database host adress - do not Change!
$dbname = 'eam'; // MYSQL database name
$dbuser = 'root'; // Mysql Datbase user
$dbpass = 'root'; // Mysql Datbase password
?>
