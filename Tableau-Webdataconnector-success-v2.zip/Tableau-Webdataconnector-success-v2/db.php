<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'ajaveed');
define('DB_PASSWORD', 'ajaveed');
define('DB_DATABASE', 'mcafee');
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>
