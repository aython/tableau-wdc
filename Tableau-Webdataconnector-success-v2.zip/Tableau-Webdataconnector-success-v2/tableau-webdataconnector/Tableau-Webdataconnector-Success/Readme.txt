index.php - has data which output to json you can host it and take the url

p.js - tableau js file to establish connection - place the url in js file

earthquakewdc.html - has the html page