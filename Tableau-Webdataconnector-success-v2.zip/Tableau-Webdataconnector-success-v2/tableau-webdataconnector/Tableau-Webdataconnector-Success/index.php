<?php


    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: PUT, GET, POST");
    header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");


ini_set('error_reporting', E_STRICT);

//$myObj->name = "John";
//$myObj->age = 30;
//$myObj->city = "New York";
//$myJSON = json_encode($myObj);

$arr = array('user1' => [array('firstname' => 'jack', 'lastname' => 'kool'),array('firstname' => 'Maksood', 'lastname' => 'Ahmed')]);
$gh = json_encode($arr);
//echo $myJSON;
echo $gh;
?>